# Templates

By default the extension suggests using [preset/web-hd](https://cloud.google.com/transcoder/docs/concepts/overview#job_template) for transcoding.

Custom templates can be created [here](https://cloud.google.com/transcoder/docs/how-to/job-templates).
